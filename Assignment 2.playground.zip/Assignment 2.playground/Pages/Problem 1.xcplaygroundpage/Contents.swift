import UIKit

// Problem 1: FizzBuzz
// Loop from 1 to 100 and print numbers or "Fizz", "Buzz", "FizzBuzz"

for number in 1...100 {
    if number % 3 == 0 && number % 5 == 0 {
        print("FizzBuzz")   // Multiple of 3 and 5
    } else if number % 3 == 0 {
        print("Fizz")       // Multiple of 3
    } else if number % 5 == 0 {
        print("Buzz")       // Multiple of 5
    } else {
        print(number)       // Otherwise, just print the number
    }
}

