// Problem 1: FizzBuzz
// Loop from 1 to 100 and print numbers or "Fizz", "Buzz", "FizzBuzz"

for number in 1...100 {
    if number % 3 == 0 && number % 5 == 0 {
        print("FizzBuzz")   // Multiple of 3 and 5
    } else if number % 3 == 0 {
        print("Fizz")       // Multiple of 3
    } else if number % 5 == 0 {
        print("Buzz")       // Multiple of 5
    } else {
        print(number)       // Otherwise, just print the number
    }
}




// Problem 2: Prime Numbers
// Function to check if a number is prime
func isPrime(_ number: Int) -> Bool {
    if number < 2 { return false }  // 0 and 1 are not prime
    
    for i in 2..<number {
        if number % i == 0 {
            return false  // Found a divisor, not prime
        }
    }
    return true
}

// Print all prime numbers between 1 and 100
for n in 1...100 {
    if isPrime(n) {
        print(n)
    }
}




// Problem 3: Temperature Converter
// Convert Celsius, Fahrenheit, Kelvin

func celsiusToFahrenheit(_ c: Double) -> Double {
    return (c * 9/5) + 32
}

func celsiusToKelvin(_ c: Double) -> Double {
    return c + 273.15
}

func fahrenheitToCelsius(_ f: Double) -> Double {
    return (f - 32) * 5/9
}

func kelvinToCelsius(_ k: Double) -> Double {
    return k - 273.15
}

// Example: simulate user input
let value: Double = 25
let unit: String = "C"  // pretend user typed "C"

if unit == "C" {
    print("Celsius: \(value), Fahrenheit: \(celsiusToFahrenheit(value)), Kelvin: \(celsiusToKelvin(value))")
} else if unit == "F" {
    let c = fahrenheitToCelsius(value)
    print("Fahrenheit: \(value), Celsius: \(c), Kelvin: \(celsiusToKelvin(c))")
} else if unit == "K" {
    let c = kelvinToCelsius(value)
    print("Kelvin: \(value), Celsius: \(c), Fahrenheit: \(celsiusToFahrenheit(c))")
}




// Problem 4: Shopping List Manager

var shoppingList: [String] = []

// Adding items
shoppingList.append("Milk")
shoppingList.append("Bread")
shoppingList.append("Apples")

// Removing item
if let index = shoppingList.firstIndex(of: "Bread") {
    shoppingList.remove(at: index)
}

// Display list
print("Current shopping list:")
for item in shoppingList {
    print("- \(item)")
}




// Problem 5: Word Frequency Counter

let sentence = "Swift is great, and Swift is fun!"
let words = sentence.lowercased()
    .components(separatedBy: CharacterSet.alphanumerics.inverted) // split by non-letters
    .filter { !$0.isEmpty }

var frequency: [String: Int] = [:]

for word in words {
    frequency[word, default: 0] += 1
}

for (word, count) in frequency {
    print("\(word): \(count)")
}




// Problem 6: Fibonacci Sequence
func fibonacci(_ n: Int) -> [Int] {
    if n <= 0 { return [] }
    if n == 1 { return [0] }
    if n == 2 { return [0, 1] }
    
    var sequence = [0, 1]
    for i in 2..<n {
        let next = sequence[i-1] + sequence[i-2]
        sequence.append(next)
    }
    return sequence
}

print(fibonacci(10))




// Problem 7: Grade Calculator
let students = ["Alice": 85, "Bob": 72, "Charlie": 90, "Diana": 65]

// Calculate average
let scores = Array(students.values)
let average = Double(scores.reduce(0, +)) / Double(scores.count)

// Find highest & lowest
if let maxScore = scores.max(), let minScore = scores.min() {
    print("Highest score: \(maxScore)")
    print("Lowest score: \(minScore)")
}

for (name, score) in students {
    let status = score >= Int(average) ? "above average" : "below average"
    print("\(name): \(score) (\(status))")
}




// Problem 8: Palindrome Checker
func isPalindrome(_ text: String) -> Bool {
    let cleaned = text.lowercased()
        .filter { $0.isLetter }   // ignore punctuation & spaces
    return cleaned == String(cleaned.reversed())
}

print(isPalindrome("Racecar"))     // true
print(isPalindrome("Hello"))       // false




// Problem 9: Simple Calculator

func add(_ a: Double, _ b: Double) -> Double { return a + b }
func subtract(_ a: Double, _ b: Double) -> Double { return a - b }
func multiply(_ a: Double, _ b: Double) -> Double { return a * b }
func divide(_ a: Double, _ b: Double) -> Double? {
    return b == 0 ? nil : a / b
}

// Example usage
let x = 10.0
let y = 5.0
let op = "/"  // pretend user typed this

switch op {
case "+": print(add(x, y))
case "-": print(subtract(x, y))
case "*": print(multiply(x, y))
case "/":
    if let result = divide(x, y) {
        print(result)
    } else {
        print("Error: Division by zero")
    }
default: print("Unknown operation")
}




// Problem 10: Unique Characters
func hasUniqueCharacters(_ text: String) -> Bool {
    var seen: Set<Character> = []
    for ch in text {
        if seen.contains(ch) {
            return false
        }
        seen.insert(ch)
    }
    return true
}

print(hasUniqueCharacters("Swift"))  // true
print(hasUniqueCharacters("Hello"))  // false

