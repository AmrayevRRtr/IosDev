// Online Swift compiler to run Swift program online
// Print "Try programiz.pro" message

// Step 1
let firstName: String = "Ruslan"
let lastName: String = "Amrayev"
var age: Int = 20
let birthYear: Int = 2005
var isStudent: Bool = true
var height: Double = 174


var weight: Double = 64.5
var country: String = "Kazakhstan"
var city: String = "Almaty"

// Bonus challenge
let currentYear: Int = 2005
let calculatedAge: Int = currentYear - birthYear

// Step 2
var hobby: String = "football"
var numberOfHobbies: Int = 3
var favoriteNumber: Int = 10
var isHobbyCreative: Bool = false
var favoriteMusicGenre: String = "Rap&Hip-Hop"
var favoriteFootballTeam: String = "Liverpool"


// Step 3
let lifeStory: String = "My name is \(lastName) \(firstName). I am \(age) years old, born in \(birthYear). I am currently a student: \(isStudent). I enjoy \(hobby), which is a creative hobby: \(isHobbyCreative). I have \(numberOfHobbies) hobbies in total, and my favorite number is \(favoriteNumber)."


// Step 4
print(lifeStory, terminator: "\n\n")


// Bonus Task
var futureGoals: String = "In the future, I want to become a professional golang developer 👨‍💻📱"

print(lifeStory + futureGoals)
