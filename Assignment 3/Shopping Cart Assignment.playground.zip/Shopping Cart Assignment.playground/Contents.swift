import UIKit
import Foundation

// MARK: - Test Scenarios

// 1. Create sample products
let laptop = Product(
    id: UUID().uuidString,
    name: "MacBook Air",
    price: 1299.99,
    category: .electronics,
    description: "Lightweight Apple laptop",
    stockQuantity: 5
)

let book = Product(
    id: UUID().uuidString,
    name: "Swift Programming",
    price: 39.99,
    category: .books,
    description: "Learn Swift with examples",
    stockQuantity: 10
)

let headphones = Product(
    id: UUID().uuidString,
    name: "AirPods",
    price: 199.99,
    category: .electronics,
    description: "Wireless Apple headphones",
    stockQuantity: 3
)

// 2. Create a shopping cart
nonisolated(unsafe) let
cart = ShoppingCart()

// 3. Test adding items to cart
cart.addItem(product: laptop, quantity: 1)
cart.addItem(product: book, quantity: 2)

// 4. Test adding same product again (should increase quantity)
cart.addItem(product: laptop, quantity: 1)  // laptop total = 2

// 5. Print cart info
print("\n🛒 Cart Summary:")
print("Subtotal: $\(cart.subtotal)")
print("Item count: \(cart.itemCount)")

// 6. Test discount (set manually)
cart.discountType = .percentage(10)
print("Discount: $\(cart.discountAmount)")
print("Total after discount: $\(cart.total)")

// 7. Test removing an item
cart.removeItem(productId: book.id)
print("After removing book, item count: \(cart.itemCount)")

// 8. Demonstrate reference type behavior
@MainActor func modifyCart(_ cart: ShoppingCart) {
    cart.addItem(product: headphones, quantity: 1)
}
modifyCart(cart)  // affects the same cart object
print("After modifyCart(), item count: \(cart.itemCount)")

// 9. Demonstrate value type behavior (struct)
let item1 = CartItem(product: book, quantity: 1)
var item2 = item1
item2.updateQuantity(5)
print("\nValue Type Check:")
print("item1 quantity = \(item1.quantity)")  // stays 1
print("item2 quantity = \(item2.quantity)")  // becomes 5

// 10. Create address
let address = Address(
    street: "123 Apple St",
    city: "Cupertino",
    zipCode: "95014",
    country: "USA"
)

// 11. Create order from cart
let order = Order(
    orderId: UUID().uuidString,
    items: cart.items,
    subtotal: cart.subtotal,
    discountAmount: cart.discountAmount,
    total: cart.total,
    timestamp: Date(),
    shippingAddress: address
)

// 12. Clear the cart after order
cart.clearCart()
print("\n📦 Order Created:")
print("Order items count: \(order.itemCount)") // not 0
print("Cart items count: \(cart.itemCount)")   // 0 after clear
print("Shipping address:\n\(address.formattedAddress)")

// 13. Demonstrate user placing order
let user = User(userId: UUID().uuidString, name: "Alice", email: "alice@example.com")
user.placeOrder(order)
print("\n👤 User Info:")
print("User total spent: $\(user.totalSpent)")


