public struct Address {
    var street: String
    var city: String
    var zipCode: String
    var country: String
    
    public init(street: String, city: String, zipCode: String, country: String) {
        self.street = street
        self.city = city
        self.zipCode = zipCode
        self.country = country
    }
    
    // Full formatted address
    public var formattedAddress: String {
        return "\(street)\n\(city), \(zipCode)\n\(country)"
    }
    
}
