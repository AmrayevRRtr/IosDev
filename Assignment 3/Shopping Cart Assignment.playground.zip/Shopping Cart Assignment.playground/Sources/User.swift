// User model
public class User {
    let userId: String          // unique user ID
    let name: String            // user name
    let email: String           // user email
    private(set) var orderHistory: [Order]  // user's past orders
    
    // Initialize user data
    public init(userId: String, name: String, email: String) {
        self.userId = userId
        self.name = name
        self.email = email
        self.orderHistory = []
    }
    
    // Add new order to history
    public func placeOrder(_ order: Order) {
        orderHistory.append(order)
    }
    
    // Total money spent by user
    public var totalSpent: Double {
        var sum = 0.0
        for order in orderHistory {
            sum += order.total
        }
        return sum
    }
}
