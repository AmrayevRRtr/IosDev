import UIKit

// Order model
public struct Order {
    public let orderId: String          // unique order ID
    public let items: [CartItem]        // list of purchased items
    public let subtotal: Double         // total before discount
    public let discountAmount: Double   // discount value
    public let total: Double            // final price after discount
    public let timestamp: Date          // order date and time
    public let shippingAddress: Address // delivery address
    
    // Total number of items in the order
    public var itemCount: Int {
        var totalAmount = 0
        for item in items {
            totalAmount += item.quantity
        }
        return totalAmount
    }
    
    public init(orderId: String, items: [CartItem], subtotal: Double, discountAmount: Double, total: Double, timestamp: Date, shippingAddress: Address) {
        self.orderId = orderId
        self.items = items
        self.subtotal = subtotal
        self.discountAmount = discountAmount
        self.total = total
        self.timestamp = timestamp
        self.shippingAddress = shippingAddress
    }
}
