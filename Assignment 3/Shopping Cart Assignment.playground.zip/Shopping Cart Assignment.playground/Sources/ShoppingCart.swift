// Shopping cart class
public class ShoppingCart {
    private(set) public var items: [CartItem]       // list of cart items
    public let discountCode: String?                // optional discount code
    public var discountType: DiscountType?          // discount type (percent, fixed, etc.)
    
    // Types of discounts
    public enum DiscountType {
        case percentage(Double)           // e.g. 10% off
        case fixedAmount(Double)          // e.g. $5 off
        case buyXGetY(buy: Int, get: Int) // e.g. Buy 2 Get 1 Free
    }

    // Empty cart by default
    public init() {                       // make initializer public
        self.items = []
        self.discountCode = nil
    }
    
    // Add item to cart
    public func addItem(product: Product, quantity: Int = 1) -> Bool { //make public
        guard quantity > 0 else {
            print("Cannot add zero or negative quantity")
            return false
        }
        guard quantity <= product.stockQuantity else {
            print("Not enough stock for \(product.name)")
            return false
        }
        
        // If product already exists, just increase quantity
        if let index = items.firstIndex(where: { $0.product.id == product.id }) {
            var existing = items[index]
            existing.increaseQuantity(by: quantity)
            items[index] = existing
        } else {
            // Otherwise, add as new item
            let newItem = CartItem(product: product, quantity: quantity)
            items.append(newItem)
        }
        
        print("Added \(quantity)x \(product.name) to cart.")
        return true
    }
    
    // Remove item by product ID
    public func removeItem(productId: String) {
        items.removeAll { $0.product.id == productId }
    }
    
    // Update item quantity
    public func updateItemQuantity(productId: String, quantity: Int) {
        if quantity <= 0 {
            removeItem(productId: productId)
            return
        }
        guard let index = items.firstIndex(where: { $0.product.id == productId }) else {
            print("Product not found")
            return
        }
        var item = items[index]
        item.updateQuantity(quantity)
        items[index] = item
    }
    
    // Clear all items
    public func clearCart() {
        items.removeAll()
    }
    
    // Calculate total before discount
    public var subtotal: Double {
        return items.reduce(0) { $0 + $1.subtotal }
    }
    
    // Calculate discount amount
    public var discountAmount: Double {
        guard let discount = discountType else { return 0.0 }
        
        switch discount {
        case .percentage(let percent):
            return subtotal * (percent / 100.0)
        case .fixedAmount(let amount):
            // 🔹 Fix logic: should just return the discount, not subtotal - amount
            return min(amount, subtotal)
        case .buyXGetY(let buy, let get):
            let totalItems = itemCount
            guard totalItems >= buy else { return 0.0 }
            let freeItems = (totalItems / (buy + get)) * get
            let averagePrice = subtotal / Double(totalItems)
            return Double(freeItems) * averagePrice
        }
    }
    
    // Final total after discount
    public var total: Double {
        let total = subtotal - discountAmount
        return total >= 0 ? total : 0
    }
    
    // Total item count
    public var itemCount: Int {
        return items.reduce(0) { $0 + $1.quantity }
    }
    
    // Check if cart is empty
    public var isEmpty: Bool {
        return items.isEmpty
    }
}
