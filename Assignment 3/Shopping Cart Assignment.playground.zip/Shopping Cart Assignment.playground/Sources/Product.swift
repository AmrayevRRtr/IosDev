public struct Product {
    public let id: String
    public let name: String
    public var price: Double
    public let category: Category
    public var description: String
    public var stockQuantity: Int
    
    public enum Category: String {
        case electronics, clothing, food, books
    }
    
    public var displayPrice: String {
        String(format: "$%.2f", price)
    }
    
    // Make init public
    public init(id: String, name: String, price: Double, category: Category, description: String, stockQuantity: Int) {
        self.id = id
        self.name = name
        self.price = price
        self.category = category
        self.description = description
        self.stockQuantity = stockQuantity
    }
}
