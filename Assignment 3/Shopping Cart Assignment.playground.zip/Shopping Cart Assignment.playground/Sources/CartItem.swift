// Represents one item in the shopping cart
public struct CartItem {
    public let product: Product        // The product itself
    public var quantity: Int           // How many units are in the cart
    
    // Computed property: total price for this item
    public var subtotal: Double {
        product.price * Double(quantity)
    }
    
    // Custom initializer (needed for public access outside the module)
    public init(product: Product, quantity: Int) {
        self.product = product
        self.quantity = quantity
    }
    
    // Change the quantity directly
    public mutating func updateQuantity(_ newQuantity: Int) {
        guard newQuantity > 0 else {
            print("Invalid quantity")
            return
        }
        self.quantity = newQuantity
    }
    
    // Increase the quantity by a specific amount
    public mutating func increaseQuantity(by amount: Int) {
        guard amount > 0 else {
            print("Increase amount must be positive")
            return
        }
        self.quantity += amount
    }
}
